#!/bin/sh

npm run dev &
json-server --watch eventos.json
