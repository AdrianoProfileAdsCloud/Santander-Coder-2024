function BotaoIncrementar({incrementar}) {
    return (
        <button onClick={incrementar}>Incrementar</button>
    );
}

export default BotaoIncrementar